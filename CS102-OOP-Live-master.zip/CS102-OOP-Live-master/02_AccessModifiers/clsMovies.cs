﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02_AccessModifiers
{
    internal class clsMovies
    {
        public string movieName = "The Good, The Bad, The Ugly";

    }
}
