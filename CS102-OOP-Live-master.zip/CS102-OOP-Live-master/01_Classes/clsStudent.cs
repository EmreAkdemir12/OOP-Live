﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_Classes
{
    internal class clsStudent
    {
        // Sınıfın kimliğini hazırladık bir anlamda...
        public string OgrAd; // dışa açık personelin adı
        public string OgrSoyad; // dışa açık personelin soyadı
        public string OgrSinif;
        public byte Not1;
        public byte Not2;
        public byte Ortalama;

        public void setInfos()
        {

        }

        public int getStatus()
        {
            return 0;
        }

    }
}
